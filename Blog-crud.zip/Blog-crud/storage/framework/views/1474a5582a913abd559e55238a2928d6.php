<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title><?php echo e($post['title']); ?></title>
    <script defer src="<?php echo e(asset('js/main.js')); ?>"></script>
</head>
<body class="bg-gray-500">
    <header>
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </header>

    <main class="flex flex-row">
        <div class="m-2 bg-white rounded border-2 border-black p-2">
            <p class="text-2xl"><?php echo e($post['title']); ?></p>
            <p class="text-sm">Category <?php echo e($post['category']); ?></p>
            <p><?php echo e($post['content']); ?></p>
            <p class="text-sm">Published on: <?php echo e($post['created_at']); ?></p>
            <p class="text-sm">Updated on: <?php echo e($post['updated_at']); ?></p>
            <?php if($post['user_id'] == session()->get('uuid')|| session()->get('level') == 1): ?>
                <a href="/editpost?id=<?php echo e($post['id']); ?>"><button class="p-2 m-1 transition-all duration-300 bg-orange-500 hover:bg-orange-700 rounded text-white">Edit</button></a>
                <a href="/deletepost?id=<?php echo e($post['id']); ?>"><button class="p-2 m-1 transition-all duration-300 bg-red-500 hover:bg-red-700 rounded text-white">delete</button></a>
            <?php endif; ?>
        </div>
    </main>
</body>
</html><?php /**PATH C:\Users\Thimo\Desktop\school\programming\Pro2-2-Laravel-CRUD\Blog-crud\resources\views/details.blade.php ENDPATH**/ ?>