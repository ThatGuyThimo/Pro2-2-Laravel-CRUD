<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>My Blogs</title>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</head>
<body class="bg-gray-500">
    <header>
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </header>

    <section class="flex flex-col text-white">
        <h1 class="text-white font-bold text-3xl m-5" >Blogs</h1>
        
        <div class="flex flex-row">
            <form class="flex flex-row" id="searchForm" method="GET" action="">
                <div class="flex">
                    <p class="m-2" >Category: </p>
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label id='<?php echo e($value["name"]); ?>LBL' class=" bg-blue-500 m-2 p-2 rounded transition-all duration-300 hover:bg-blue-700"><?php echo e($value['name']); ?>

                        <input type="checkbox" id='<?php echo e($value["name"]); ?>BTN' onchange="updateSelectedCategory(this)" name='<?php echo e($value["name"]); ?>' class="">
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
    
                <input id="searchbar" class="rounded m-2 text-black" name="search" type="search" placeholder="Search blog" >
                <button id="searchBTN" type="submit" value="search" class="m-1 transition-all duration-300 bg-green-600 rounded p-2 hover:bg-green-700" >Search</button>
                
                <meta name="_token" content="<?php echo e(csrf_token()); ?>">
            </form>
        </div>
    </section>

    <main class="flex flex-row">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($value['user_id'] == session()->get('uuid')): ?>
        <div class="m-2 bg-white rounded border-2 border-black p-2">
            <p class="text-2xl"><?php echo e($value['title']); ?></p>
            <p><?php echo e($value['content']); ?></p>
            <a href="/details?id=<?php echo e($value['id']); ?>"><button class="p-2 m-1 transition-all duration-300 bg-blue-500 hover:bg-blue-700 rounded text-white">Details</button></a>
            <a href="/editpost?id=<?php echo e($value['id']); ?>"><button class="p-2 m-1 transition-all duration-300 bg-orange-500 hover:bg-orange-700 rounded text-white">Edit</button></a>
            <a href="/deletepost?id=<?php echo e($value['id']); ?>"><button class="p-2 m-1 transition-all duration-300 bg-red-500 hover:bg-red-700 rounded text-white">delete</button></a>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </main>
</body>
</html><?php /**PATH C:\Users\Thimo\Desktop\school\programming\Pro2-2-Laravel-CRUD\Blog-crud\resources\views/myblogs.blade.php ENDPATH**/ ?>