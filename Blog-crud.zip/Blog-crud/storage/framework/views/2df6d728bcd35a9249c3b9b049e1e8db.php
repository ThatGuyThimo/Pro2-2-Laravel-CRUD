
<div class="flex flex-row items-stretch bg-[#333333]">
    <ul class="text-white p-2 flex">
        <a href="/" class="hover:text-gray-400 mr-2 " ><li><img width="60px" src="<?php echo e(asset('/images/GS.svg')); ?>"></li></a>
        <?php if(session()->has('username')): ?> 
        <a href="/editprofile" class="hover:text-gray-400 mr-2 " ><li><?php echo e(session()->get('username')); ?></li></a>
        <a href="/logout" class="hover:text-gray-400 mr-2 " ><li>Logout</li></a>
        <?php if(session('visits') >= 3 ): ?>
        <a href="/createblog" class="hover:text-gray-400 mr-2 " ><li>Create blog</li></a>
        <a href="/myposts" class="hover:text-gray-400 mr-2 " ><li>My blogs</li></a>
        <?php endif; ?>
        <?php else: ?>
        <a href="/login" class="hover:text-gray-400 mr-2 " ><li>Login</li></a>
        <?php endif; ?>
        <a href="/blogs" class="hover:text-gray-400 mr-2 " > <li>Blogs</li></a>
    </ul>
</div><?php /**PATH C:\Users\Thimo\Desktop\school\programming\Pro2-2-Laravel-CRUD\Blog-crud\resources\views/navbar.blade.php ENDPATH**/ ?>