<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Create Blog</title>
</head>
<body class="bg-gray-500">
    <header>
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <section class="flex flex-col items-center m-2">
        <div class="bg-gray-600 border-2 w-2/3 p-2 border-black rounded">
            <form class="flex flex-col" method="post" action="/createpost">
                <h1 class="text-white text-center">Create Blog</h1>
                <p class="text-white">Title</p>
                <input name="title" class="rounded w-60 border-black p-1" type="text" placeholder="Title">
                <p class="text-white">Category</p>
                <select name="category" class="rounded w-60 border-black p-1">
                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option id='<?php echo e($value["name"]); ?>BTN' value='<?php echo e($value["name"]); ?>'><?php echo e($value['name']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <p class="text-white">Content</p>
                <textarea name="content" class="rounded h-60 border-black p-1" type="text" placeholder="Content"></textarea>
                <div class="flex flex-col items-center mt-2">
    	    	<button type="submit" name="submit" value="submit" class="transition-all duration-300 bg-blue-600 rounded p-2 hover:bg-blue-700">Submit</button>
                </div>
                <?php echo csrf_field(); ?>
            </form>
            <?php if(isset($error)): ?>
            <div class="text-center">
                <p class="text-red-500"><?php echo e($error); ?></p>
            </div>
            <?php endif; ?>
        </div>
    </section>
</body>
</html><?php /**PATH C:\Users\Thimo\Desktop\school\programming\Pro2-2-Laravel-CRUD\Blog-crud\resources\views/createblog.blade.php ENDPATH**/ ?>