
<div class="flex flex-row items-stretch bg-[#333333]">
    <ul class="text-white p-2 flex">
        <a href="/" class="hover:text-gray-400 mr-2 " ><li><img width="60px" src="<?php echo e(asset('/images/GS.svg')); ?>"></li></a>
        <?php if(session()->has('username')): ?> 
        <a href="<?php echo e(route('editprofile')); ?>" class="hover:text-gray-400 mr-2 " ><li><?php echo e(session()->get('username')); ?></li></a>
        <a href="<?php echo e(route('logout')); ?>" class="hover:text-gray-400 mr-2 " ><li>Logout</li></a>
        <?php if(session('visits') >= 3 ): ?>
        <a href="<?php echo e(route('createblog')); ?>" class="hover:text-gray-400 mr-2 " ><li>Create blog</li></a>
        <a href="<?php echo e(route('myposts')); ?>" class="hover:text-gray-400 mr-2 " ><li>My blogs</li></a>
        <?php endif; ?>
        <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="hover:text-gray-400 mr-2 " ><li>Login</li></a>
        <?php endif; ?>
        <a href="<?php echo e(route('blogs')); ?>" class="hover:text-gray-400 mr-2 " > <li>Blogs</li></a>
    </ul>
</div><?php /**PATH C:\Users\Thimo\Desktop\school\programming\Pro2-2-Laravel-CRUD\Blog-crud\resources\views/navbar.blade.php ENDPATH**/ ?>